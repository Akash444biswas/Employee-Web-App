import React from "react";
import { NavLink, Link } from "react-router-dom";
import { FaShoppingBag } from "react-icons/fa";
import Header from "./Layouts/Header";
import Midder from "./Layouts/Midder";
const Home = () => {
  return (
    <>
      <Header></Header>
      <Midder></Midder>
    </>
  );
};

export default Home;
